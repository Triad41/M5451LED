

#include "M5451LED.h"

M5451::M5451(byte clkPin, byte dataPin)
{
  int i;
 
  clockPin = clkPin;
  serDataPin = dataPin;
 
  pinMode(clockPin, OUTPUT);      // sets the digital pin as output
  pinMode(serDataPin, OUTPUT);      // sets the digital pin as output

  // Clear out the device so we can clock in items
  digitalWrite(serDataPin,LOW); 
  //35 outputs
  for (i=0;i< M5451_NUMOUTS+2;i++)
    {
    mydelay(M5451_CLK);
    digitalWrite(clockPin,HIGH);
    mydelay(M5451_CLK);
    digitalWrite(clockPin,LOW);   
    }
}

const long M5451::powersOf10[] = {
  1, // 10^0
  10,
  100,
  1000,
  10000,
  100000,
  1000000,
  10000000,
  100000000,
  1000000000}; // 10^9


void M5451::setNumber(long numToShow, byte decPlaces) //long
{
  setNewNum(numToShow, decPlaces);
}

void M5451::setNumber(unsigned long numToShow, byte decPlaces) //unsigned long
{
  setNewNum(numToShow, decPlaces);
}

void M5451::setNumber(int numToShow, byte decPlaces) //int
{
  setNewNum(numToShow, decPlaces);
}

void M5451::setNumber(unsigned int numToShow, byte decPlaces) //unsigned int
{
  setNewNum(numToShow, decPlaces);
}

void M5451::setNumber(char numToShow, byte decPlaces) //char
{
  setNewNum(numToShow, decPlaces);
}

void M5451::setNumber(byte numToShow, byte decPlaces) //byte
{
  setNewNum(numToShow, decPlaces);
}

void M5451::setNumber(float numToShow, byte decPlaces) //float
{
  numToShow = numToShow * powersOf10[decPlaces];
  // Modify the number so that it is rounded to an integer correctly
  numToShow += (numToShow >= 0) ? 0.5f : -0.5f;
  setNewNum(numToShow, decPlaces);
}

void M5451::BlankDisplay()
{
  for(byte x=0; x <8; x++)
  {
    digitCodes[x] = 0;
  }
  setiopins(0x00000000,ExtendedIOPins);
}

void M5451::mydelay(int clk)
{
  int i;
  for (i=0;i< clk;i++);
}

void M5451::setiopins(unsigned long int a, unsigned int b)
{
	int i;
	
	if((clockPin==3)&&(serDataPin==2))
	{
		//Faster Code Example
		PORTD &= ~_BV(PD3);   // clock is 3
		PORTD &= ~_BV(PD2);   // data is 2
		PORTD |= _BV(PD3);
		PORTD &= ~_BV(PD3);
		PORTD |= _BV(PD2);
		PORTD |= _BV(PD3);
		PORTD &= ~_BV(PD3);

		// Write the bits
		for (i=0;i< M5451_NUMOUTS;i++)
		{
			int serDataVal;
			if (i<21) 
			{ 
				serDataVal = (a&1); a>>=1;
			}
			else 
			{ 
				serDataVal = (b&1); b>>=1;
			}
			if(serDataVal)
			{
				PORTD |= _BV(PD2);
			}
			else
			{
				PORTD &= ~_BV(PD2);
			}
			PORTD |= _BV(PD3);
			PORTD &= ~_BV(PD3);
		}
	}
	else
	{
		// Write the initial "start" signal
		digitalWrite(clockPin,LOW);
		mydelay(M5451_CLK);
		digitalWrite(serDataPin,LOW);
		mydelay(M5451_CLK);
		digitalWrite(clockPin,HIGH);
		mydelay(M5451_CLK);
		digitalWrite(clockPin,LOW);
		mydelay(M5451_CLK/2);
		digitalWrite(serDataPin,HIGH);
		mydelay(M5451_CLK/2);
		digitalWrite(clockPin,HIGH);
		mydelay(M5451_CLK);
		digitalWrite(clockPin,LOW);

		// Write the bits
		for (i=0;i< M5451_NUMOUTS;i++)
		{
			int serDataVal;
			if (i<21) 
			{ 
				serDataVal = (a&1); a>>=1;
			}
			else 
			{ 
				serDataVal = (b&1); b>>=1;
			}
			mydelay(M5451_CLK/2);
			digitalWrite(serDataPin,serDataVal);
			mydelay(M5451_CLK/2);
			digitalWrite(clockPin,HIGH);
			mydelay(M5451_CLK);
			digitalWrite(clockPin,LOW);
		}
	}

}

// findDigits
/******************************************************************************/
// Decides what each digit will display.
// Enforces the upper and lower limits on the number to be displayed.
void M5451::findDigits(long numToShow, byte decPlaces, byte digits[]) {
  static const long maxNum = powersOf10[MAXNUMDIGITS] - 1;
  static const long minNum = -(powersOf10[MAXNUMDIGITS - 1] - 1);

  // If the number is out of range, just display dashes
 if (numToShow > maxNum || numToShow < minNum) {
    for (byte digitNum = 0 ; digitNum < MAXNUMDIGITS ; digitNum++){
      digits[digitNum] = DASH;
    }
  }
  else{
    byte digitNum = 0;
    
    // Convert all number to positive values
    if (numToShow < 0) {
      digits[0] = DASH;
      digitNum = 1; // Skip the first iteration
      numToShow = -numToShow;
    }

    // Find all digits for the base 10 representation, starting with the most
    // significant digit
    for ( ; digitNum < MAXNUMDIGITS ; digitNum++){
      long factor = powersOf10[MAXNUMDIGITS - 1 - digitNum];
      digits[digitNum] = numToShow / factor;
      numToShow -= digits[digitNum] * factor;
    }

    // Find unnnecessary leading zeros and set them to BLANK
    for (digitNum = 0 ; digitNum < (MAXNUMDIGITS - 1 - decPlaces) ; digitNum++){
      if (digits[digitNum] == 0) {
        digits[digitNum] = BLANK;
      }
      // Exit once the first non-zero number is encountered
      else if (digits[digitNum] <= 9) {
        break;
      }
    }

  }
}

void M5451::setNewNum(long numToShow, byte decPlaces){
  byte digits[MAXNUMDIGITS];
  findDigits(numToShow, decPlaces, digits);
  setDigitCodes(digits, decPlaces);
}

void M5451::setDigitCodes(byte digits[], byte decPlaces) {

  // The codes below indicate which segments must be illuminated to display
  // each number.
  static const byte digitCodeMap[] = {
    B00111111, // 0
    B00000110, // 1
    B01011011, // 2
    B01001111, // 3
    B01100110, // 4
    B01101101, // 5
    B01111101, // 6
    B00000111, // 7
    B01111111, // 8
    B01101111, // 9
    B00000000, // BLANK
    B01000000    }; // DASH

  // Set the digitCode for each digit in the display
  for (byte digitNum = 0 ; digitNum < MAXNUMDIGITS ; digitNum++) {
    digitCodes[digitNum] = digitCodeMap[digits[digitNum]];
    // Set the decimal place segment
    if (decPlaces > 0)
    {
    if (digitNum == MAXNUMDIGITS - 1 - decPlaces) 
    {
      digitCodes[digitNum] |= B10000000;
    }
    }
  }
}

