
#ifndef M5451LED_H
#define M5451LED_H

#if (ARDUINO >= 100)
 #include <Arduino.h>
#else
 #include <WProgram.h>
 #include <pins_arduino.h>
#endif

#define MAXNUMDIGITS 8
#define M5451_NUMOUTS 35
#define M5451_CLK 0
#define BLANK 10 // Must match with 'digitCodeMap', defined in 'setDigitCodes' 
#define DASH 11

// Map M5451 has 35 I/O Lines
//   000 00000000 0000 0000 00000000 00000000
//   |              || |  | |      | |      |
//   |              || |  | |      | ----------> First Display Bank Segments DP G F E D C B A (digits 7,6,5,4) 7 being left most
//   |              || |  | |      |
//   |              || |  | -------------------> Second Display Bank Segments DP G F E D C B A (digits 3,2 1,0) 0 being right most
//   |              || |  |
//   |              || ------------------------> Digit Enable b0001- digits 7 and 3, b0010 - digits 6 and 2, 5 and 1, 4 and 0
//   |              |--------------------------> LED Enable 
//   |              |
//   ------------------------------------------> Extended I/O (15) on the Header 0x0001 = Pint 37, 0x0002 = Pint 36, 0x0004 = pin 35
  
class M5451
{
  public:
  byte clockPin;
  byte brightPin;
  byte serDataPin;

 volatile byte digitCodes[MAXNUMDIGITS];
 volatile unsigned int ExtendedIOPins = 0x0000;  //Only 15 exist so the highest bit is not used
 
 static const long powersOf10[10];
     
 M5451(byte clockPin,byte serDataPin);
     
  void setNumber(long numToShow, byte decPlaces);
  void setNumber(unsigned long numToShow, byte decPlaces);
  void setNumber(int numToShow, byte decPlaces);
  void setNumber(unsigned int numToShow, byte decPlaces);
  void setNumber(char numToShow, byte decPlaces);
  void setNumber(byte numToShow, byte decPlaces);
  void setNumber(float numToShow, byte decPlaces);

  void setiopins(unsigned long int LEDdisplay, unsigned int ExtendedIO=0);

  void BlankDisplay();
  
  private:
  void mydelay(int clk);
  void setNewNum(long numToShow, byte decPlaces);
  void findDigits(long numToShow, byte decPlaces, byte nums[]);
  void setDigitCodes(byte nums[], byte decPlaces);
};
  
#endif




